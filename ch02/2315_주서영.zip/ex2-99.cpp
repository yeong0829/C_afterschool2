#include <stdio.h>
int main(void) {
	printf("�й�: %d\n", 321665);
	printf("�̸�: %s\n", "ȫ�浿");
	printf("�й�: %c", 'A');

	return 0;
}